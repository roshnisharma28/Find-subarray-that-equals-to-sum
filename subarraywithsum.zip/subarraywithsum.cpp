#include<iostream>
using namespace std;
int main(){
    int arr[7]={1,4,20,3,10,8,9};
    int sum=28;
    int n=7;
    int left=0;
    int right=0;
    int cur_sum=0;
    while(cur_sum!=sum){
        if(cur_sum<sum){
            cur_sum+=arr[right];
            right++;
        }
        else{
            cur_sum-=arr[left];
            left++;
        }
    }
    for(int i=left;i<right;i++){
        cout<<arr[i]<<" ";
    }
    
}
